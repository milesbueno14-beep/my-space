# My Space

Aplicativo pessoal de organização e planejamento, feito em HTML, CSS e JavaScript.

## Publicar no GitHub Pages

1. Envie `index.html` para a raiz do repositório `my-space`.
2. Abra **Settings → Pages**.
3. Em **Build and deployment**, selecione **Deploy from a branch**.
4. Escolha a branch `main` e a pasta `/ (root)`, depois salve.

Os registros do aplicativo ficam no armazenamento local do navegador/dispositivo. Para evitar perda de dados, use a opção de exportar backup dentro do aplicativo.
